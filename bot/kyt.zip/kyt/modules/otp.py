import json
import requests
from telethon import TelegramClient, events, Button

api_id = '24322241'  # ganti dengan API ID Anda
api_hash = '3cead2bdb4698c60932c20634ab25251'  # ganti dengan API Hash Anda
bot_token = '7437148233:AAFdoGI9UZlFJrx3_AxJ5K0KpiLuFRFgSWw'  # ganti dengan Token Bot Anda

# Daftar ID pengguna yang diizinkan
allowed_users = [1708391805, 987654321]  # Ganti dengan ID Telegram pengguna yang diizinkan

bot = TelegramClient('bot', api_id, api_hash).start(bot_token=bot_token)

# Handler untuk perintah /login
@bot.on(events.NewMessage(pattern='/login'))
async def start(event):
    sender = await event.get_sender()
    if sender.id not in allowed_users:
        await event.respond("Bajingan Asu Kontol Memek, **MINIMAL IZIN DULU LAH SAMA** @Tomketstore.")
        return

    await event.respond(
        '**SILAHKAN LOGIN !!**\n\nMasukan Nomor XL Dengan Awalan 62/08',
        buttons=[Button.inline(' Login OTP V7', b'login_api')]
    )

# Handler untuk callback query 'login_api'
@bot.on(events.CallbackQuery(data=b'login_api'))
async def login_api(event):
    sender = await event.get_sender()
    if sender.id not in allowed_users:
        await event.respond("Anda tidak memiliki izin untuk menggunakan bot ini.")
        return

    async def login_api_(event):
        sender = await event.get_sender()
        chat = event.chat_id

        async with bot.conversation(chat) as CLIENT_NUMBER:
            await event.respond('`Exit = back to menu \n\nInput Nomor XL:`')
            CLIENT_NUMBER = await CLIENT_NUMBER.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            CLIENT_NUMBER = CLIENT_NUMBER.raw_text
            if CLIENT_NUMBER.lower() == "exit":
                await event.respond("Kembali ke menu", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
                return

        otp_url = 'http://103.184.122.36:5000/api/request-otp'
        otp_payload = {
            'phoneNumber': CLIENT_NUMBER
        }

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer 0a1ccba4-e6fc-498c-af2f-5f889c765aaa'
        }

        try:
            response = requests.post(otp_url, json=otp_payload, headers=headers)
            if response.status_code == 200:
                otp_response = response.json()
                if 'OTP success terkirim' in otp_response.get('message', ''):
                    async with bot.conversation(chat) as Quota:
                        await event.respond("**Masukkan OTP:**")
                        try:
                            response = await Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id), timeout=300)
                            otp = response.raw_text

                            verify_url = 'http://103.184.122.36:5000/api/valid-otp'
                            verify_payload = {
                                'phoneNumber': CLIENT_NUMBER,
                                'otp': otp
                            }

                            verify_response = requests.post(verify_url, json=verify_payload, headers=headers)
                            if verify_response.status_code == 200:
                                verify_result = verify_response.json()
                                if 'Login OTP success' in verify_result.get('message', ''):
                                    await event.respond("**Login Sukses**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
                                else:
                                    await event.respond("**Verifikasi OTP gagal. Silakan coba lagi.**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
                            else:
                                await event.respond("**Gagal mengirim permintaan verifikasi OTP. Silakan coba lagi.**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
                        except asyncio.TimeoutError:
                            await event.respond("**Code OTP expired. Silakan coba login lagi.**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
                            return
                else:
                    await event.respond("**Gagal mengirim permintaan OTP. Silakan coba lagi.**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
            else:
                await event.respond(f"**Gagal mengirim permintaan OTP. Status Code: {response.status_code}**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])
        except requests.exceptions.RequestException as e:
            await event.respond(f"**Gagal melakukan permintaan ke server: {str(e)}**", buttons=[[Button.inline("🔙ᴍᴇɴᴜ", b"menu")]])

    await login_api_(event)

bot.run_until_disconnected()